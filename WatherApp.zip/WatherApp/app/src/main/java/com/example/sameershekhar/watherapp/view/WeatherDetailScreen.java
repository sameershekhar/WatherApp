package com.example.sameershekhar.watherapp.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.sameershekhar.watherapp.R;

public class WeatherDetailScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_detail_screen);
    }
}
