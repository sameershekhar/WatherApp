package com.example.sameershekhar.watherapp.utils;

public class Constant {


    //https://api.openweathermap.org/data/2.5/weather?q=Bangalore&appid=033c87b42d7f95bb216a4560994aa80a
    public static String BASE_URL="http://api.openweathermap.org/";
    public static String APP_ID = "033c87b42d7f95bb216a4560994aa80a";
}
