package com.example.sameershekhar.watherapp.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.sameershekhar.watherapp.R;
import com.example.sameershekhar.watherapp.model.WeatherResponse;

public class HomeScreenAdapter extends RecyclerView.Adapter<HomeScreenAdapter.MyViewHolder> {

    Context context;
    WeatherResponse weatherResponse;

    public HomeScreenAdapter(Context context, WeatherResponse weatherResponse) {
        this.context = context;
        this.weatherResponse = weatherResponse;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
     View view= LayoutInflater.from(context).inflate(R.layout.home_screen_recycler_item,viewGroup,false);
     return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
